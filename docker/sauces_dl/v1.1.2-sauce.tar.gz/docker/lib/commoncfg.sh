
#
##
## Import common configuration variables
##
## This is the new commonconfig.cfg mostly for user to edit but also can be appended automatically
## 
## WARNING THIS FILE MAY BE AUTOMATICALLY APPENDED TO
##
#

# UNCOMMENT THIS FOR CUT DOWN OR CUSTOM INSTALLATION & CONFIGURE IT (without cloning git repository)
#export GIT_ROOT=/root/sd-forge-webui-docker

